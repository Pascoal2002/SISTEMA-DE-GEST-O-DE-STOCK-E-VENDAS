import { NextResponse, type NextRequest } from 'next/server';
import { jwtVerify } from 'jose';

// Primeira barreira: sem sessão válida, só a página de login é acessível.
// (As páginas e acções voltam a verificar o perfil no servidor.)
export async function proxy(req: NextRequest) {
  const token = req.cookies.get('sessao')?.value;
  let valido = false;
  if (token) {
    try {
      await jwtVerify(token, new TextEncoder().encode(process.env.AUTH_SECRET ?? ''));
      valido = true;
    } catch {}
  }
  const { pathname } = req.nextUrl;
  if (!valido && pathname !== '/login') return NextResponse.redirect(new URL('/login', req.url));
  if (valido && pathname === '/login') return NextResponse.redirect(new URL('/dashboard', req.url));
  return NextResponse.next();
}

export const config = { matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\\..*).*)'] };
