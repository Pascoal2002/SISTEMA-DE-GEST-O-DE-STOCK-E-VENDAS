'use server';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { query } from '@/lib/db';
import { requerPerfil } from '@/lib/auth';
import { ErroNegocio, executar } from '@/lib/erros';
import { idSchema, produtoSchema } from '@/lib/validacoes';

async function guardarImagem(f: FormDataEntryValue | null): Promise<string | null> {
  if (!(f instanceof File) || f.size === 0) return null;
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(f.type)) throw new ErroNegocio('A imagem deve ser JPG, PNG ou WEBP.');
  if (f.size > 2 * 1024 * 1024) throw new ErroNegocio('A imagem não pode exceder 2 MB.');
  const ext = f.type === 'image/png' ? 'png' : f.type === 'image/webp' ? 'webp' : 'jpg';
  const nome = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const dir = path.join(process.cwd(), 'public', 'imagens', 'produtos');
  await mkdir(dir, { recursive: true });
  await writeFile(path.join(dir, nome), Buffer.from(await f.arrayBuffer()));
  return `/imagens/produtos/${nome}`;
}

export async function criarProduto(fd: FormData) {
  const s = await requerPerfil(['admin', 'gestor']);
  await executar(async () => {
    const d = produtoSchema.parse(Object.fromEntries(fd));
    if (d.preco_venda < d.preco_compra && s.perfil !== 'admin')
      throw new ErroNegocio('O preço de venda é inferior ao de compra. Só o administrador pode autorizar.'); // RN08
    const imagem = await guardarImagem(fd.get('imagem'));
    await query(
      'INSERT INTO produto (codigo, nome, descricao, categoria_id, preco_compra, preco_venda, stock_minimo, imagem) VALUES (?,?,?,?,?,?,?,?)',
      [d.codigo, d.nome, d.descricao, d.categoria_id, d.preco_compra, d.preco_venda, d.stock_minimo, imagem]);
  }, '/produtos', '/produtos/novo', 'Produto registado. Para dar stock inicial, registe uma entrada.');
}

export async function actualizarProduto(fd: FormData) {
  const s = await requerPerfil(['admin', 'gestor']);
  const id = idSchema.parse(fd.get('id'));
  await executar(async () => {
    const d = produtoSchema.parse(Object.fromEntries(fd));
    if (d.preco_venda < d.preco_compra && s.perfil !== 'admin')
      throw new ErroNegocio('O preço de venda é inferior ao de compra. Só o administrador pode autorizar.');
    const imagem = await guardarImagem(fd.get('imagem'));
    await query(
      `UPDATE produto SET codigo=?, nome=?, descricao=?, categoria_id=?, preco_compra=?, preco_venda=?, stock_minimo=?,
       imagem = COALESCE(?, imagem) WHERE id = ?`,
      [d.codigo, d.nome, d.descricao, d.categoria_id, d.preco_compra, d.preco_venda, d.stock_minimo, imagem, id]);
  }, '/produtos', `/produtos/${id}`, 'Produto actualizado.');
}

export async function alternarProduto(fd: FormData) {
  await requerPerfil(['admin', 'gestor']);
  const id = idSchema.parse(fd.get('id'));
  await executar(async () => {
    await query('UPDATE produto SET activo = 1 - activo WHERE id = ?', [id]);
  }, '/produtos', '/produtos', 'Estado do produto alterado.');
}
