'use server';
import bcrypt from 'bcryptjs';
import { query } from '@/lib/db';
import { requerPerfil } from '@/lib/auth';
import { ErroNegocio, executar } from '@/lib/erros';
import { idSchema, senhaSchema, utilizadorSchema } from '@/lib/validacoes';

export async function criarUtilizador(fd: FormData) {
  await requerPerfil(['admin']);
  await executar(async () => {
    const d = utilizadorSchema.parse(Object.fromEntries(fd));
    const hash = await bcrypt.hash(senhaSchema.parse(fd.get('senha')), 10);
    await query('INSERT INTO utilizador (nome, email, senha_hash, perfil) VALUES (?,?,?,?)', [d.nome, d.email, hash, d.perfil]);
  }, '/utilizadores', '/utilizadores', 'Utilizador criado.');
}

export async function actualizarUtilizador(fd: FormData) {
  const s = await requerPerfil(['admin']);
  await executar(async () => {
    const id = idSchema.parse(fd.get('id'));
    const d = utilizadorSchema.parse(Object.fromEntries(fd));
    if (id === s.id && d.perfil !== 'admin') throw new ErroNegocio('Não pode retirar o seu próprio perfil de administrador.');
    await query('UPDATE utilizador SET nome=?, email=?, perfil=? WHERE id=?', [d.nome, d.email, d.perfil, id]);
    const nova = String(fd.get('senha') ?? '');
    if (nova) await query('UPDATE utilizador SET senha_hash=? WHERE id=?', [await bcrypt.hash(senhaSchema.parse(nova), 10), id]);
  }, '/utilizadores', '/utilizadores', 'Utilizador actualizado.');
}

export async function alternarUtilizador(fd: FormData) {
  const s = await requerPerfil(['admin']);
  await executar(async () => {
    const id = idSchema.parse(fd.get('id'));
    if (id === s.id) throw new ErroNegocio('Não pode desactivar a sua própria conta.');
    await query('UPDATE utilizador SET activo = 1 - activo WHERE id = ?', [id]);
  }, '/utilizadores', '/utilizadores', 'Estado do utilizador alterado.');
}
