'use server';
import { z } from 'zod';
import { requerPerfil } from '@/lib/auth';
import { executar } from '@/lib/erros';
import { dataSchema, lerItens } from '@/lib/validacoes';
import { registarEntrada, registarSaida } from '@/services/stock.service';

export async function criarEntrada(fd: FormData) {
  const s = await requerPerfil(['admin', 'gestor']);
  await executar(async () => {
    const itens = lerItens(fd);
    const fornecedorId = z.coerce.number().int().positive('Escolha o fornecedor.').parse(fd.get('fornecedor_id'));
    const id = await registarEntrada({
      fornecedorId,
      data: dataSchema.parse(fd.get('data')),
      documento: String(fd.get('documento') ?? '').trim().slice(0, 60),
      itens: itens.map((i) => ({ produto_id: i.produto_id, quantidade: i.quantidade, preco: i.preco ?? 0 })),
    }, s.id);
    return `/entradas/${id}`;
  }, '/entradas', '/entradas/nova', 'Entrada registada. O stock foi actualizado.');
}

export async function criarSaida(fd: FormData) {
  const s = await requerPerfil(['admin', 'gestor']);
  await executar(async () => {
    const motivo = z.enum(['perda', 'avaria', 'devolucao_fornecedor', 'ajuste'], { errorMap: () => ({ message: 'Indique o motivo da saída.' }) })
      .parse(fd.get('motivo'));
    await registarSaida({
      motivo,
      obs: String(fd.get('obs') ?? '').trim().slice(0, 255) || undefined,
      itens: lerItens(fd).map((i) => ({ produto_id: i.produto_id, quantidade: i.quantidade })),
    }, s.id);
  }, '/saidas', '/saidas/nova', 'Saída registada. O stock foi actualizado.');
}
