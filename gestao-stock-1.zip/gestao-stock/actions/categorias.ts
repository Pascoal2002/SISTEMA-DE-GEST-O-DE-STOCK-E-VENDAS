'use server';
import { query } from '@/lib/db';
import { requerPerfil } from '@/lib/auth';
import { executar } from '@/lib/erros';
import { idSchema } from '@/lib/validacoes';
import { z } from 'zod';

const nomeSchema = z.string().trim().min(2, 'Indique o nome da categoria.').max(100);

export async function criarCategoria(fd: FormData) {
  await requerPerfil(['admin', 'gestor']);
  await executar(async () => {
    await query('INSERT INTO categoria (nome) VALUES (?)', [nomeSchema.parse(fd.get('nome'))]);
  }, '/categorias', '/categorias', 'Categoria criada.');
}

export async function renomearCategoria(fd: FormData) {
  await requerPerfil(['admin', 'gestor']);
  await executar(async () => {
    await query('UPDATE categoria SET nome = ? WHERE id = ?', [nomeSchema.parse(fd.get('nome')), idSchema.parse(fd.get('id'))]);
  }, '/categorias', '/categorias', 'Categoria actualizada.');
}

export async function alternarCategoria(fd: FormData) {
  await requerPerfil(['admin', 'gestor']);
  await executar(async () => {
    await query('UPDATE categoria SET activo = 1 - activo WHERE id = ?', [idSchema.parse(fd.get('id'))]);
  }, '/categorias', '/categorias', 'Estado da categoria alterado.');
}
