'use server';
import bcrypt from 'bcryptjs';
import { redirect } from 'next/navigation';
import { query } from '@/lib/db';
import { criarSessao, terminarSessao } from '@/lib/auth';
import { ErroNegocio, executar } from '@/lib/erros';

export async function entrar(fd: FormData) {
  const email = String(fd.get('email') ?? '').trim().toLowerCase();
  const senha = String(fd.get('senha') ?? '');
  await executar(async () => {
    const [u] = await query('SELECT id, nome, senha_hash, perfil, activo FROM utilizador WHERE email = ?', [email]);
    if (!u || !u.activo || !(await bcrypt.compare(senha, u.senha_hash))) throw new ErroNegocio('E-mail ou palavra-passe incorrectos.');
    await criarSessao({ id: u.id, nome: u.nome, perfil: u.perfil });
  }, '/dashboard', '/login');
}

export async function sair() {
  await terminarSessao();
  redirect('/login');
}
