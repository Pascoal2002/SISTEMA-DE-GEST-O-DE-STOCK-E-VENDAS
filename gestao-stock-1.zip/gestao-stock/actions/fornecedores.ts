'use server';
import { query } from '@/lib/db';
import { requerPerfil } from '@/lib/auth';
import { executar } from '@/lib/erros';
import { fornecedorSchema, idSchema } from '@/lib/validacoes';

export async function criarFornecedor(fd: FormData) {
  await requerPerfil(['admin', 'gestor']);
  await executar(async () => {
    const d = fornecedorSchema.parse(Object.fromEntries(fd));
    await query('INSERT INTO fornecedor (nome, nif, telefone, email, endereco) VALUES (?,?,?,?,?)', [d.nome, d.nif, d.telefone, d.email, d.endereco]);
  }, '/fornecedores', '/fornecedores/novo', 'Fornecedor registado.');
}

export async function actualizarFornecedor(fd: FormData) {
  await requerPerfil(['admin', 'gestor']);
  const id = idSchema.parse(fd.get('id'));
  await executar(async () => {
    const d = fornecedorSchema.parse(Object.fromEntries(fd));
    await query('UPDATE fornecedor SET nome=?, nif=?, telefone=?, email=?, endereco=? WHERE id=?', [d.nome, d.nif, d.telefone, d.email, d.endereco, id]);
  }, '/fornecedores', `/fornecedores/${id}`, 'Fornecedor actualizado.');
}

export async function alternarFornecedor(fd: FormData) {
  await requerPerfil(['admin', 'gestor']);
  await executar(async () => {
    await query('UPDATE fornecedor SET activo = 1 - activo WHERE id = ?', [idSchema.parse(fd.get('id'))]);
  }, '/fornecedores', '/fornecedores', 'Estado do fornecedor alterado.');
}
