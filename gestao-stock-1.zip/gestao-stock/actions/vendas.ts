'use server';
import { z } from 'zod';
import { requerPerfil } from '@/lib/auth';
import { executar } from '@/lib/erros';
import { idSchema, lerItens } from '@/lib/validacoes';
import { anularVenda, criarVenda } from '@/services/venda.service';

export async function registarVenda(fd: FormData) {
  const s = await requerPerfil(['admin', 'vendedor']);
  await executar(async () => {
    const forma = z.enum(['numerario', 'tpa', 'transferencia'], { errorMap: () => ({ message: 'Escolha a forma de pagamento.' }) })
      .parse(fd.get('forma'));
    const id = await criarVenda({ forma, itens: lerItens(fd).map((i) => ({ produto_id: i.produto_id, quantidade: i.quantidade })) }, s.id);
    return `/vendas/${id}`;
  }, '/vendas', '/vendas/nova', 'Venda confirmada.');
}

export async function anularVendaAccao(fd: FormData) {
  const s = await requerPerfil(['admin']);
  const id = idSchema.parse(fd.get('id'));
  await executar(async () => {
    await anularVenda(id, s.id);
  }, `/vendas/${id}`, `/vendas/${id}`, 'Venda anulada e stock reposto.');
}
