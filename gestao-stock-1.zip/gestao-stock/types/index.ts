export type Perfil = 'admin' | 'gestor' | 'vendedor';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type Row = Record<string, any>;
export type SP = Promise<Record<string, string | undefined>>;
