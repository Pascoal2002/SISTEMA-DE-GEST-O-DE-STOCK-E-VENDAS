// Cria a base de dados, as tabelas e o administrador inicial.
import mysql from 'mysql2/promise';
import bcrypt from 'bcryptjs';
import { readFileSync } from 'node:fs';

const e = process.env;
const nomeBd = e.DB_NAME ?? 'gestao_stock';
const c = await mysql.createConnection({
  host: e.DB_HOST ?? 'localhost',
  port: Number(e.DB_PORT ?? 3306),
  user: e.DB_USER ?? 'root',
  password: e.DB_PASSWORD ?? '',
  multipleStatements: true,
});

await c.query(`CREATE DATABASE IF NOT EXISTS \`${nomeBd}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
await c.query(`USE \`${nomeBd}\``);
await c.query(readFileSync(new URL('../database/schema.sql', import.meta.url), 'utf8'));

const [r] = await c.query('SELECT COUNT(*) AS n FROM utilizador');
if (r[0].n === 0) {
  const email = e.ADMIN_EMAIL ?? 'admin@empresa.ao';
  const senha = e.ADMIN_SENHA ?? 'Admin@12345';
  await c.query('INSERT INTO utilizador (nome, email, senha_hash, perfil) VALUES (?,?,?,?)', ['Administrador', email, await bcrypt.hash(senha, 10), 'admin']);
  await c.query("INSERT IGNORE INTO categoria (nome) VALUES ('Geral')");
  console.log(`Administrador criado: ${email} / ${senha}  (altere a palavra-passe depois de entrar)`);
}
console.log(`Base de dados "${nomeBd}" pronta.`);
await c.end();
