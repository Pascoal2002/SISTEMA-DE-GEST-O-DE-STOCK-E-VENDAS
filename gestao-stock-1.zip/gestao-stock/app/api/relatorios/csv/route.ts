import type { NextRequest } from 'next/server';
import { obterSessao } from '@/lib/auth';
import { gerar, TIPOS } from '@/services/relatorio.service';

export async function GET(req: NextRequest) {
  const s = await obterSessao();
  const p = req.nextUrl.searchParams;
  const tipo = TIPOS.find((t) => t.id === p.get('tipo'));
  if (!s || !tipo || !tipo.perfis.includes(s.perfil)) return new Response('Sem permissão', { status: 403 });

  const r = await gerar(tipo.id, p.get('de') ?? '', p.get('ate') ?? '');
  const celula = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  // BOM + ";" para o Excel abrir correctamente em português
  const csv = '\uFEFF' + [r.colunas, ...r.linhas].map((l) => l.map(celula).join(';')).join('\r\n');
  return new Response(csv, {
    headers: { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="${tipo.id}.csv"` },
  });
}
