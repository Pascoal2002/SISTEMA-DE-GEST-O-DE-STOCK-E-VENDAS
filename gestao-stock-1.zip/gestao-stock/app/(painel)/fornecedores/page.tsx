import Link from 'next/link';
import { alternarFornecedor } from '@/actions/fornecedores';
import Aviso from '@/components/Aviso';
import { requerPerfil } from '@/lib/auth';
import { query } from '@/lib/db';
import type { SP } from '@/types';

export default async function Fornecedores({ searchParams }: { searchParams: SP }) {
  await requerPerfil(['admin', 'gestor']);
  const sp = await searchParams;
  const q = (sp.q ?? '').trim();
  const lista = await query('SELECT * FROM fornecedor WHERE nome LIKE ? OR nif LIKE ? ORDER BY nome', [`%${q}%`, `%${q}%`]);
  return (
    <>
      <div className="cabeca"><h1>Fornecedores</h1><Link className="btn" href="/fornecedores/novo">+ Novo fornecedor</Link></div>
      <Aviso sp={sp} />
      <form className="cartao filtros" method="get">
        <label>Pesquisar<input name="q" defaultValue={q} placeholder="Nome ou NIF" /></label>
        <button className="btn">Filtrar</button>
      </form>
      <div className="cartao"><div className="tabela"><table>
        <thead><tr><th>Nome</th><th>NIF</th><th>Telefone</th><th>E-mail</th><th>Estado</th><th /></tr></thead>
        <tbody>
          {lista.length === 0 && <tr><td colSpan={6} className="mudo">Nenhum fornecedor encontrado.</td></tr>}
          {lista.map((f) => (
            <tr key={f.id}>
              <td>{f.nome}</td><td>{f.nif ?? '—'}</td><td>{f.telefone ?? '—'}</td><td>{f.email ?? '—'}</td>
              <td>{f.activo ? 'Activo' : 'Inactivo'}</td>
              <td className="acoes">
                <Link className="btn sec peq" href={`/fornecedores/${f.id}`}>Editar / histórico</Link>
                <form action={alternarFornecedor}><input type="hidden" name="id" value={f.id} /><button className="btn sec peq">{f.activo ? 'Desactivar' : 'Activar'}</button></form>
              </td>
            </tr>
          ))}
        </tbody>
      </table></div></div>
    </>
  );
}
