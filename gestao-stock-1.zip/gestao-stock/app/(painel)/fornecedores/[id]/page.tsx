import Link from 'next/link';
import { notFound } from 'next/navigation';
import { actualizarFornecedor } from '@/actions/fornecedores';
import Aviso from '@/components/Aviso';
import FormFornecedor from '@/components/FormFornecedor';
import { requerPerfil } from '@/lib/auth';
import { query } from '@/lib/db';
import { fmtData, kz } from '@/lib/utils';
import type { SP } from '@/types';

export default async function EditarFornecedor({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: SP }) {
  await requerPerfil(['admin', 'gestor']);
  const { id } = await params;
  const sp = await searchParams;
  const [f] = await query('SELECT * FROM fornecedor WHERE id = ?', [Number(id) || 0]);
  if (!f) notFound();
  const historico = await query('SELECT id, numero, data_entrada, documento, total FROM entrada WHERE fornecedor_id = ? ORDER BY id DESC LIMIT 50', [f.id]);
  return (
    <>
      <h1>{f.nome}</h1>
      <Aviso sp={sp} />
      <FormFornecedor acao={actualizarFornecedor} fornecedor={f} />
      <div className="cartao">
        <h2>Histórico de fornecimentos</h2>
        {historico.length === 0 ? <p className="mudo">Ainda não há entradas deste fornecedor.</p> : (
          <div className="tabela"><table>
            <thead><tr><th>Nº</th><th>Data</th><th>Documento</th><th>Total</th></tr></thead>
            <tbody>{historico.map((e) => <tr key={e.id}><td><Link href={`/entradas/${e.id}`}>{e.numero}</Link></td><td>{fmtData(e.data_entrada)}</td><td>{e.documento ?? '—'}</td><td>{kz(e.total)}</td></tr>)}</tbody>
          </table></div>
        )}
      </div>
    </>
  );
}
