import { criarFornecedor } from '@/actions/fornecedores';
import Aviso from '@/components/Aviso';
import FormFornecedor from '@/components/FormFornecedor';
import { requerPerfil } from '@/lib/auth';
import type { SP } from '@/types';

export default async function NovoFornecedor({ searchParams }: { searchParams: SP }) {
  await requerPerfil(['admin', 'gestor']);
  const sp = await searchParams;
  return (
    <>
      <h1>Novo fornecedor</h1>
      <Aviso sp={sp} />
      <FormFornecedor acao={criarFornecedor} />
    </>
  );
}
