import { alternarCategoria, criarCategoria, renomearCategoria } from '@/actions/categorias';
import Aviso from '@/components/Aviso';
import { requerPerfil } from '@/lib/auth';
import { query } from '@/lib/db';
import type { SP } from '@/types';

export default async function Categorias({ searchParams }: { searchParams: SP }) {
  await requerPerfil(['admin', 'gestor']);
  const sp = await searchParams;
  const cats = await query('SELECT c.*, (SELECT COUNT(*) FROM produto p WHERE p.categoria_id = c.id) produtos FROM categoria c ORDER BY c.nome');
  return (
    <>
      <h1>Categorias</h1>
      <Aviso sp={sp} />
      <form action={criarCategoria} className="cartao filtros">
        <label>Nova categoria<input name="nome" required maxLength={100} /></label>
        <button className="btn">Adicionar</button>
      </form>
      <div className="grelha">
        {cats.map((c) => (
          <div className="cartao" key={c.id}>
            <form action={renomearCategoria} className="filtros">
              <input type="hidden" name="id" value={c.id} />
              <label>Nome<input name="nome" defaultValue={c.nome} required maxLength={100} /></label>
              <button className="btn sec">Guardar</button>
            </form>
            <div className="acoes">
              <span className={`tag${c.activo ? '' : ' anulada'}`}>{c.activo ? 'Activa' : 'Inactiva'}</span>
              <span className="mudo">{c.produtos} produto(s)</span>
              <form action={alternarCategoria}><input type="hidden" name="id" value={c.id} /><button className="btn sec peq">{c.activo ? 'Desactivar' : 'Activar'}</button></form>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
