import { criarEntrada } from '@/actions/stock';
import Aviso from '@/components/Aviso';
import SeletorItens from '@/components/SeletorItens';
import { requerPerfil } from '@/lib/auth';
import { query } from '@/lib/db';
import { hoje } from '@/lib/utils';
import type { SP } from '@/types';

export default async function NovaEntrada({ searchParams }: { searchParams: SP }) {
  await requerPerfil(['admin', 'gestor']);
  const sp = await searchParams;
  const [fornecedores, produtos] = await Promise.all([
    query('SELECT id, nome FROM fornecedor WHERE activo = 1 ORDER BY nome'),
    query('SELECT id, codigo, nome, stock_actual, preco_compra, preco_venda FROM produto WHERE activo = 1 ORDER BY nome'),
  ]);
  const lista = produtos.map((p) => ({ ...p, preco_compra: Number(p.preco_compra), preco_venda: Number(p.preco_venda) }));
  return (
    <>
      <h1>Nova entrada de stock</h1>
      <Aviso sp={sp} />
      {fornecedores.length === 0 && <div className="aviso erro">Registe primeiro um fornecedor.</div>}
      <form action={criarEntrada} className="cartao">
        <div className="form">
          <label>Fornecedor
            <select name="fornecedor_id" required defaultValue="">
              <option value="" disabled>Escolha…</option>
              {fornecedores.map((f) => <option key={f.id} value={f.id}>{f.nome}</option>)}
            </select>
          </label>
          <label>Data<input name="data" type="date" required defaultValue={hoje()} /></label>
          <label>Nº do documento (opcional)<input name="documento" maxLength={60} /></label>
        </div>
        <SeletorItens produtos={lista} modo="entrada" rotulo="Registar entrada" />
      </form>
    </>
  );
}
