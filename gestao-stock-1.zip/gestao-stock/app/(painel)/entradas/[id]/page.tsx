import { notFound } from 'next/navigation';
import Aviso from '@/components/Aviso';
import { requerPerfil } from '@/lib/auth';
import { query } from '@/lib/db';
import { fmtData, kz } from '@/lib/utils';
import type { SP } from '@/types';

export default async function EntradaDetalhe({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: SP }) {
  await requerPerfil(['admin', 'gestor']);
  const { id } = await params;
  const sp = await searchParams;
  const [e] = await query(
    `SELECT e.*, f.nome fornecedor, u.nome utilizador FROM entrada e JOIN fornecedor f ON f.id = e.fornecedor_id
     JOIN utilizador u ON u.id = e.utilizador_id WHERE e.id = ?`, [Number(id) || 0]);
  if (!e) notFound();
  const itens = await query('SELECT i.quantidade, i.preco_custo, p.codigo, p.nome FROM item_entrada i JOIN produto p ON p.id = i.produto_id WHERE i.entrada_id = ?', [e.id]);
  return (
    <>
      <h1>Entrada {e.numero}</h1>
      <Aviso sp={sp} />
      <div className="cartao">
        <p>Fornecedor: <strong>{e.fornecedor}</strong> · Data: {fmtData(e.data_entrada)} · Documento: {e.documento ?? '—'}<br />Registada por {e.utilizador}</p>
        <div className="tabela"><table>
          <thead><tr><th>Produto</th><th>Qtd</th><th>Preço de custo</th><th>Subtotal</th></tr></thead>
          <tbody>{itens.map((i) => <tr key={i.codigo}><td>{i.nome}</td><td>{i.quantidade}</td><td>{kz(i.preco_custo)}</td><td>{kz(i.quantidade * Number(i.preco_custo))}</td></tr>)}</tbody>
        </table></div>
        <p className="total">Total: <strong>{kz(e.total)}</strong></p>
      </div>
    </>
  );
}
