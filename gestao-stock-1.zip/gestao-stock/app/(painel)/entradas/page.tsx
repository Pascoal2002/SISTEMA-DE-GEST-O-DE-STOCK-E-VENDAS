import Link from 'next/link';
import Aviso from '@/components/Aviso';
import Paginacao from '@/components/Paginacao';
import { requerPerfil } from '@/lib/auth';
import { query } from '@/lib/db';
import { fmtData, kz } from '@/lib/utils';
import type { SP } from '@/types';

const POR = 20;

export default async function Entradas({ searchParams }: { searchParams: SP }) {
  await requerPerfil(['admin', 'gestor']);
  const sp = await searchParams;
  const pagina = Math.max(1, Number(sp.pagina) || 1);
  const [{ n }] = await query('SELECT COUNT(*) n FROM entrada');
  const lista = await query(
    `SELECT e.id, e.numero, e.data_entrada, e.documento, e.total, f.nome fornecedor, u.nome utilizador
     FROM entrada e JOIN fornecedor f ON f.id = e.fornecedor_id JOIN utilizador u ON u.id = e.utilizador_id
     ORDER BY e.id DESC LIMIT ? OFFSET ?`, [POR, (pagina - 1) * POR]);
  return (
    <>
      <div className="cabeca"><h1>Entradas de stock</h1><Link className="btn" href="/entradas/nova">+ Nova entrada</Link></div>
      <Aviso sp={sp} />
      <div className="cartao">
        <div className="tabela"><table>
          <thead><tr><th>Nº</th><th>Data</th><th>Fornecedor</th><th>Documento</th><th>Total</th><th>Registado por</th></tr></thead>
          <tbody>
            {lista.length === 0 && <tr><td colSpan={6} className="mudo">Ainda não há entradas.</td></tr>}
            {lista.map((e) => (
              <tr key={e.id}><td><Link href={`/entradas/${e.id}`}>{e.numero}</Link></td><td>{fmtData(e.data_entrada)}</td><td>{e.fornecedor}</td><td>{e.documento ?? '—'}</td><td>{kz(e.total)}</td><td>{e.utilizador}</td></tr>
            ))}
          </tbody>
        </table></div>
        <Paginacao rota="/entradas" params={{}} pagina={pagina} total={n} por={POR} />
      </div>
    </>
  );
}
