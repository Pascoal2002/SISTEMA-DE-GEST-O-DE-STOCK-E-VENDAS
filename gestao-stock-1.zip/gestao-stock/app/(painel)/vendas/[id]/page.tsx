import { notFound } from 'next/navigation';
import { anularVendaAccao } from '@/actions/vendas';
import Aviso from '@/components/Aviso';
import { BotaoConfirmar, BotaoImprimir } from '@/components/Botoes';
import { requerPerfil } from '@/lib/auth';
import { query } from '@/lib/db';
import { fmtData, kz, ROTULO_PAGAMENTO } from '@/lib/utils';
import type { SP } from '@/types';

export default async function Recibo({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: SP }) {
  const s = await requerPerfil(['admin', 'vendedor']);
  const { id } = await params;
  const sp = await searchParams;
  const [v] = await query('SELECT v.*, u.nome vendedor FROM venda v JOIN utilizador u ON u.id = v.utilizador_id WHERE v.id = ?', [Number(id) || 0]);
  if (!v || (s.perfil === 'vendedor' && v.utilizador_id !== s.id)) notFound();
  const itens = await query('SELECT i.quantidade, i.preco_unitario, i.subtotal, p.nome FROM item_venda i JOIN produto p ON p.id = i.produto_id WHERE i.venda_id = ?', [v.id]);
  const anulada = v.estado === 'anulada';

  return (
    <>
      <div className="cabeca nao-imprimir">
        <h1>Venda {v.numero}</h1>
        <div className="acoes">
          <BotaoImprimir>Imprimir recibo</BotaoImprimir>
          {s.perfil === 'admin' && !anulada && (
            <form action={anularVendaAccao}>
              <input type="hidden" name="id" value={v.id} />
              <BotaoConfirmar mensagem="Anular esta venda? O stock será reposto.">Anular venda</BotaoConfirmar>
            </form>
          )}
        </div>
      </div>
      <Aviso sp={sp} />
      <div className="cartao recibo">
        <h2>{process.env.EMPRESA_NOME ?? 'Gestão de Stock'}</h2>
        <div className="linha"><span>Recibo</span><strong>{v.numero}</strong></div>
        <div className="linha"><span>Data</span><span>{fmtData(v.criado_em)}</span></div>
        <div className="linha"><span>Vendedor</span><span>{v.vendedor}</span></div>
        <div className="linha"><span>Pagamento</span><span>{ROTULO_PAGAMENTO[v.forma_pagamento]}</span></div>
        {anulada && <div className="aviso erro">VENDA ANULADA em {fmtData(v.anulada_em)}</div>}
        <div className="tabela"><table>
          <thead><tr><th>Produto</th><th>Qtd</th><th>Preço</th><th>Subtotal</th></tr></thead>
          <tbody>{itens.map((i) => <tr key={i.nome}><td>{i.nome}</td><td>{i.quantidade}</td><td>{kz(i.preco_unitario)}</td><td>{kz(i.subtotal)}</td></tr>)}</tbody>
        </table></div>
        <p className="total">Total: <strong>{kz(v.total)}</strong></p>
      </div>
    </>
  );
}
