import { registarVenda } from '@/actions/vendas';
import Aviso from '@/components/Aviso';
import SeletorItens from '@/components/SeletorItens';
import { requerPerfil } from '@/lib/auth';
import { query } from '@/lib/db';
import type { SP } from '@/types';

export default async function NovaVenda({ searchParams }: { searchParams: SP }) {
  await requerPerfil(['admin', 'vendedor']);
  const sp = await searchParams;
  const produtos = await query('SELECT id, codigo, nome, stock_actual, preco_compra, preco_venda FROM produto WHERE activo = 1 AND stock_actual > 0 ORDER BY nome');
  const lista = produtos.map((p) => ({ ...p, preco_compra: Number(p.preco_compra), preco_venda: Number(p.preco_venda) }));
  return (
    <>
      <h1>Nova venda</h1>
      <Aviso sp={sp} />
      <form action={registarVenda} className="cartao">
        <label>Forma de pagamento
          <select name="forma" required defaultValue="numerario">
            <option value="numerario">Numerário</option>
            <option value="tpa">TPA</option>
            <option value="transferencia">Transferência</option>
          </select>
        </label>
        <SeletorItens produtos={lista} modo="venda" rotulo="Confirmar venda" />
      </form>
    </>
  );
}
