import Link from 'next/link';
import Aviso from '@/components/Aviso';
import Paginacao from '@/components/Paginacao';
import { requerPerfil } from '@/lib/auth';
import { query } from '@/lib/db';
import { fmtData, hoje, inicioMes, kz, ROTULO_PAGAMENTO } from '@/lib/utils';
import type { SP } from '@/types';

const POR = 20;

export default async function Vendas({ searchParams }: { searchParams: SP }) {
  const s = await requerPerfil(['admin', 'vendedor']);
  const sp = await searchParams;
  const de = sp.de || inicioMes();
  const ate = sp.ate || hoje();
  const num = (sp.numero ?? '').trim();
  const pagina = Math.max(1, Number(sp.pagina) || 1);

  const cond = ['DATE(v.criado_em) BETWEEN ? AND ?', 'v.numero LIKE ?'];
  const par: unknown[] = [de, ate, `%${num}%`];
  if (s.perfil === 'vendedor') { cond.push('v.utilizador_id = ?'); par.push(s.id); } // o vendedor vê só as suas vendas
  const onde = cond.join(' AND ');

  const [{ n }] = await query(`SELECT COUNT(*) n FROM venda v WHERE ${onde}`, par);
  const lista = await query(
    `SELECT v.id, v.numero, v.total, v.estado, v.forma_pagamento, v.criado_em, u.nome vendedor
     FROM venda v JOIN utilizador u ON u.id = v.utilizador_id WHERE ${onde} ORDER BY v.id DESC LIMIT ? OFFSET ?`,
    [...par, POR, (pagina - 1) * POR]);

  return (
    <>
      <div className="cabeca"><h1>Vendas</h1><Link className="btn" href="/vendas/nova">+ Nova venda</Link></div>
      <Aviso sp={sp} />
      <form className="cartao filtros" method="get">
        <label>De<input name="de" type="date" defaultValue={de} /></label>
        <label>Até<input name="ate" type="date" defaultValue={ate} /></label>
        <label>Nº da venda<input name="numero" defaultValue={num} placeholder="VD-2026-…" /></label>
        <button className="btn">Filtrar</button>
      </form>
      <div className="cartao">
        <div className="tabela"><table>
          <thead><tr><th>Nº</th><th>Data</th><th>Vendedor</th><th>Pagamento</th><th>Total</th><th>Estado</th></tr></thead>
          <tbody>
            {lista.length === 0 && <tr><td colSpan={6} className="mudo">Nenhuma venda neste período.</td></tr>}
            {lista.map((v) => (
              <tr key={v.id}>
                <td><Link href={`/vendas/${v.id}`}>{v.numero}</Link></td><td>{fmtData(v.criado_em)}</td><td>{v.vendedor}</td>
                <td>{ROTULO_PAGAMENTO[v.forma_pagamento]}</td><td>{kz(v.total)}</td>
                <td><span className={`tag${v.estado === 'anulada' ? ' anulada' : ''}`}>{v.estado === 'anulada' ? 'Anulada' : 'Confirmada'}</span></td>
              </tr>
            ))}
          </tbody>
        </table></div>
        <Paginacao rota="/vendas" params={{ de, ate, numero: num }} pagina={pagina} total={n} por={POR} />
      </div>
    </>
  );
}
