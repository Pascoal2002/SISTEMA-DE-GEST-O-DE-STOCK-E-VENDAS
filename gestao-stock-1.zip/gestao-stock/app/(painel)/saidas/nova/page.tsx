import { criarSaida } from '@/actions/stock';
import Aviso from '@/components/Aviso';
import SeletorItens from '@/components/SeletorItens';
import { requerPerfil } from '@/lib/auth';
import { query } from '@/lib/db';
import type { SP } from '@/types';

export default async function NovaSaida({ searchParams }: { searchParams: SP }) {
  await requerPerfil(['admin', 'gestor']);
  const sp = await searchParams;
  const produtos = await query('SELECT id, codigo, nome, stock_actual, preco_compra, preco_venda FROM produto WHERE activo = 1 AND stock_actual > 0 ORDER BY nome');
  const lista = produtos.map((p) => ({ ...p, preco_compra: Number(p.preco_compra), preco_venda: Number(p.preco_venda) }));
  return (
    <>
      <h1>Nova saída de stock</h1>
      <Aviso sp={sp} />
      <form action={criarSaida} className="cartao">
        <div className="form">
          <label>Motivo
            <select name="motivo" required defaultValue="">
              <option value="" disabled>Escolha…</option>
              <option value="perda">Perda</option>
              <option value="avaria">Avaria</option>
              <option value="devolucao_fornecedor">Devolução ao fornecedor</option>
              <option value="ajuste">Ajuste de inventário</option>
            </select>
          </label>
          <label>Observação (opcional)<input name="obs" maxLength={255} /></label>
        </div>
        <SeletorItens produtos={lista} modo="saida" rotulo="Registar saída" />
      </form>
    </>
  );
}
