import Link from 'next/link';
import Aviso from '@/components/Aviso';
import Paginacao from '@/components/Paginacao';
import { requerPerfil } from '@/lib/auth';
import { query } from '@/lib/db';
import { fmtData, ROTULO_MOTIVO } from '@/lib/utils';
import type { SP } from '@/types';

const POR = 20;

export default async function Saidas({ searchParams }: { searchParams: SP }) {
  await requerPerfil(['admin', 'gestor']);
  const sp = await searchParams;
  const pagina = Math.max(1, Number(sp.pagina) || 1);
  const filtro = "m.tipo = 'saida' AND m.motivo <> 'venda'";
  const [{ n }] = await query(`SELECT COUNT(*) n FROM movimento_stock m WHERE ${filtro}`);
  const lista = await query(
    `SELECT m.id, m.criado_em, m.motivo, m.quantidade, m.observacao, p.nome produto, u.nome utilizador
     FROM movimento_stock m JOIN produto p ON p.id = m.produto_id JOIN utilizador u ON u.id = m.utilizador_id
     WHERE ${filtro} ORDER BY m.id DESC LIMIT ? OFFSET ?`, [POR, (pagina - 1) * POR]);
  return (
    <>
      <div className="cabeca"><h1>Saídas de stock</h1><Link className="btn" href="/saidas/nova">+ Nova saída</Link></div>
      <p className="mudo">Perdas, avarias, devoluções e ajustes. As saídas por venda ficam registadas em Vendas.</p>
      <Aviso sp={sp} />
      <div className="cartao">
        <div className="tabela"><table>
          <thead><tr><th>Data</th><th>Produto</th><th>Qtd</th><th>Motivo</th><th>Observação</th><th>Registado por</th></tr></thead>
          <tbody>
            {lista.length === 0 && <tr><td colSpan={6} className="mudo">Ainda não há saídas.</td></tr>}
            {lista.map((m) => <tr key={m.id}><td>{fmtData(m.criado_em)}</td><td>{m.produto}</td><td>{m.quantidade}</td><td>{ROTULO_MOTIVO[m.motivo]}</td><td>{m.observacao ?? '—'}</td><td>{m.utilizador}</td></tr>)}
          </tbody>
        </table></div>
        <Paginacao rota="/saidas" params={{}} pagina={pagina} total={n} por={POR} />
      </div>
    </>
  );
}
