import { BotaoImprimir } from '@/components/Botoes';
import { requerPerfil } from '@/lib/auth';
import { formatar, hoje, inicioMes } from '@/lib/utils';
import { gerar, TIPOS } from '@/services/relatorio.service';
import type { SP } from '@/types';

export default async function Relatorios({ searchParams }: { searchParams: SP }) {
  const s = await requerPerfil(['admin', 'gestor']);
  const sp = await searchParams;
  const tipos = TIPOS.filter((t) => t.perfis.includes(s.perfil));
  const tipo = tipos.find((t) => t.id === sp.tipo) ?? tipos[0];
  const de = sp.de || inicioMes();
  const ate = sp.ate || hoje();
  const r = await gerar(tipo.id, de, ate);
  const csv = `/api/relatorios/csv?${new URLSearchParams({ tipo: tipo.id, de, ate })}`;
  const maximo = tipo.id === 'vendas_periodo' ? Math.max(1, ...r.linhas.map((l) => Number(l[2]))) : 0;

  return (
    <>
      <h1>Relatórios</h1>
      <form className="cartao filtros nao-imprimir" method="get">
        <label>Relatório
          <select name="tipo" defaultValue={tipo.id}>{tipos.map((t) => <option key={t.id} value={t.id}>{t.nome}</option>)}</select>
        </label>
        {tipo.periodo && <label>De<input name="de" type="date" defaultValue={de} /></label>}
        {tipo.periodo && <label>Até<input name="ate" type="date" defaultValue={ate} /></label>}
        <button className="btn">Gerar</button>
        <a className="btn sec" href={csv}>Exportar CSV</a>
        <BotaoImprimir />
      </form>
      <div className="cartao">
        <h2>{tipo.nome}{tipo.periodo ? ` · ${de} a ${ate}` : ''}</h2>
        {maximo > 0 && r.linhas.length > 0 && (
          <div className="barras" role="img" aria-label="Gráfico de vendas por dia">
            {r.linhas.map((l, i) => <div key={i} style={{ height: `${(Number(l[2]) / maximo) * 100}%` }} title={`${formatar(l[0], 'data')}: ${formatar(l[2], 'kz')}`} />)}
          </div>
        )}
        <div className="tabela"><table>
          <thead><tr>{r.colunas.map((c) => <th key={c}>{c}</th>)}</tr></thead>
          <tbody>
            {r.linhas.length === 0 && <tr><td colSpan={r.colunas.length || 1} className="mudo">Sem dados para mostrar.</td></tr>}
            {r.linhas.map((l, i) => <tr key={i}>{l.map((v, k) => <td key={k}>{formatar(v, r.fmt[k])}</td>)}</tr>)}
          </tbody>
        </table></div>
      </div>
    </>
  );
}
