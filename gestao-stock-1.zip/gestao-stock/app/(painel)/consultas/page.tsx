import Link from 'next/link';
import Paginacao from '@/components/Paginacao';
import { requerSessao } from '@/lib/auth';
import { query } from '@/lib/db';
import { fmtData, kz, ROTULO_MOTIVO } from '@/lib/utils';
import type { SP } from '@/types';

const POR = 25;

export default async function Consultas({ searchParams }: { searchParams: SP }) {
  const s = await requerSessao();
  const sp = await searchParams;
  const podeMov = s.perfil !== 'vendedor';
  const vista = podeMov && sp.vista === 'movimentos' ? 'movimentos' : 'stock';
  const pagina = Math.max(1, Number(sp.pagina) || 1);

  const abas = (
    <div className="acoes">
      <Link className={`btn ${vista === 'stock' ? '' : 'sec'}`} href="/consultas">Stock actual</Link>
      {podeMov && <Link className={`btn ${vista === 'movimentos' ? '' : 'sec'}`} href="/consultas?vista=movimentos">Movimentos</Link>}
    </div>
  );

  if (vista === 'stock') {
    const q = (sp.q ?? '').trim();
    const [{ n }] = await query('SELECT COUNT(*) n FROM produto WHERE activo = 1 AND (nome LIKE ? OR codigo LIKE ?)', [`%${q}%`, `%${q}%`]);
    const lista = await query(
      `SELECT p.codigo, p.nome, c.nome categoria, p.stock_actual, p.stock_minimo, p.preco_venda FROM produto p
       JOIN categoria c ON c.id = p.categoria_id WHERE p.activo = 1 AND (p.nome LIKE ? OR p.codigo LIKE ?) ORDER BY p.nome LIMIT ? OFFSET ?`,
      [`%${q}%`, `%${q}%`, POR, (pagina - 1) * POR]);
    return (
      <>
        <h1>Consultas</h1>{abas}
        <form className="cartao filtros" method="get">
          <label>Pesquisar produto<input name="q" defaultValue={q} placeholder="Nome ou código" /></label>
          <button className="btn">Pesquisar</button>
        </form>
        <div className="cartao">
          <div className="tabela"><table>
            <thead><tr><th>Código</th><th>Produto</th><th>Categoria</th><th>Stock</th><th>Mínimo</th><th>Preço de venda</th></tr></thead>
            <tbody>
              {lista.length === 0 && <tr><td colSpan={6} className="mudo">Nenhum produto encontrado.</td></tr>}
              {lista.map((p) => (
                <tr key={p.codigo}><td>{p.codigo}</td><td>{p.nome}</td><td>{p.categoria}</td>
                  <td><span className={`tag${p.stock_actual <= p.stock_minimo ? ' baixo' : ''}`}>{p.stock_actual}</span></td><td>{p.stock_minimo}</td><td>{kz(p.preco_venda)}</td></tr>
              ))}
            </tbody>
          </table></div>
          <Paginacao rota="/consultas" params={{ q }} pagina={pagina} total={n} por={POR} />
        </div>
      </>
    );
  }

  const produto = Number(sp.produto) || 0;
  const tipo = sp.tipo === 'entrada' || sp.tipo === 'saida' ? sp.tipo : '';
  const de = sp.de ?? '';
  const ate = sp.ate ?? '';
  const cond = ['1=1'];
  const par: unknown[] = [];
  if (produto) { cond.push('m.produto_id = ?'); par.push(produto); }
  if (tipo) { cond.push('m.tipo = ?'); par.push(tipo); }
  if (/^\d{4}-\d{2}-\d{2}$/.test(de)) { cond.push('DATE(m.criado_em) >= ?'); par.push(de); }
  if (/^\d{4}-\d{2}-\d{2}$/.test(ate)) { cond.push('DATE(m.criado_em) <= ?'); par.push(ate); }
  const onde = cond.join(' AND ');

  const [{ n }] = await query(`SELECT COUNT(*) n FROM movimento_stock m WHERE ${onde}`, par);
  const [lista, produtos] = await Promise.all([
    query(
      `SELECT m.criado_em, p.nome produto, m.tipo, m.motivo, m.quantidade, m.stock_apos, u.nome utilizador
       FROM movimento_stock m JOIN produto p ON p.id = m.produto_id JOIN utilizador u ON u.id = m.utilizador_id
       WHERE ${onde} ORDER BY m.id DESC LIMIT ? OFFSET ?`, [...par, POR, (pagina - 1) * POR]),
    query('SELECT id, nome FROM produto ORDER BY nome'),
  ]);
  return (
    <>
      <h1>Consultas</h1>{abas}
      <form className="cartao filtros" method="get">
        <input type="hidden" name="vista" value="movimentos" />
        <label>Produto
          <select name="produto" defaultValue={produto || ''}>
            <option value="">Todos</option>
            {produtos.map((p) => <option key={p.id} value={p.id}>{p.nome}</option>)}
          </select>
        </label>
        <label>Tipo
          <select name="tipo" defaultValue={tipo}><option value="">Todos</option><option value="entrada">Entradas</option><option value="saida">Saídas</option></select>
        </label>
        <label>De<input name="de" type="date" defaultValue={de} /></label>
        <label>Até<input name="ate" type="date" defaultValue={ate} /></label>
        <button className="btn">Filtrar</button>
      </form>
      <div className="cartao">
        <div className="tabela"><table>
          <thead><tr><th>Data</th><th>Produto</th><th>Tipo</th><th>Motivo</th><th>Qtd</th><th>Stock após</th><th>Utilizador</th></tr></thead>
          <tbody>
            {lista.length === 0 && <tr><td colSpan={7} className="mudo">Nenhum movimento encontrado.</td></tr>}
            {lista.map((m, i) => (
              <tr key={i}><td>{fmtData(m.criado_em)}</td><td>{m.produto}</td><td>{m.tipo === 'entrada' ? 'Entrada' : 'Saída'}</td><td>{ROTULO_MOTIVO[m.motivo]}</td><td>{m.quantidade}</td><td>{m.stock_apos}</td><td>{m.utilizador}</td></tr>
            ))}
          </tbody>
        </table></div>
        <Paginacao rota="/consultas" params={{ vista: 'movimentos', produto: produto ? String(produto) : undefined, tipo, de, ate }} pagina={pagina} total={n} por={POR} />
      </div>
    </>
  );
}
