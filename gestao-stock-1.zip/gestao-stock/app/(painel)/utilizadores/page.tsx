import { actualizarUtilizador, alternarUtilizador, criarUtilizador } from '@/actions/utilizadores';
import Aviso from '@/components/Aviso';
import { requerPerfil } from '@/lib/auth';
import { query } from '@/lib/db';
import { ROTULO_PERFIL } from '@/lib/permissoes';
import type { SP } from '@/types';

const PERFIS = Object.entries(ROTULO_PERFIL);

export default async function Utilizadores({ searchParams }: { searchParams: SP }) {
  const s = await requerPerfil(['admin']);
  const sp = await searchParams;
  const lista = await query('SELECT id, nome, email, perfil, activo FROM utilizador ORDER BY nome');
  return (
    <>
      <h1>Utilizadores</h1>
      <Aviso sp={sp} />
      <form action={criarUtilizador} className="cartao form">
        <h2 className="larga">Novo utilizador</h2>
        <label>Nome<input name="nome" required maxLength={120} /></label>
        <label>E-mail<input name="email" type="email" required maxLength={150} /></label>
        <label>Palavra-passe (mín. 8)<input name="senha" type="password" required minLength={8} autoComplete="new-password" /></label>
        <label>Perfil<select name="perfil" defaultValue="vendedor">{PERFIS.map(([v, r]) => <option key={v} value={v}>{r}</option>)}</select></label>
        <div className="larga"><button className="btn">Criar utilizador</button></div>
      </form>
      <div className="grelha">
        {lista.map((u) => (
          <div className="cartao" key={u.id}>
            <form action={actualizarUtilizador} className="form">
              <input type="hidden" name="id" value={u.id} />
              <label className="larga">Nome<input name="nome" defaultValue={u.nome} required maxLength={120} /></label>
              <label className="larga">E-mail<input name="email" type="email" defaultValue={u.email} required maxLength={150} /></label>
              <label className="larga">Perfil<select name="perfil" defaultValue={u.perfil}>{PERFIS.map(([v, r]) => <option key={v} value={v}>{r}</option>)}</select></label>
              <label className="larga">Nova palavra-passe (opcional)<input name="senha" type="password" minLength={8} autoComplete="new-password" /></label>
              <div className="larga"><button className="btn sec">Guardar</button></div>
            </form>
            <div className="acoes">
              <span className={`tag${u.activo ? '' : ' anulada'}`}>{u.activo ? 'Activo' : 'Inactivo'}</span>
              {u.id !== s.id && (
                <form action={alternarUtilizador}><input type="hidden" name="id" value={u.id} /><button className="btn sec peq">{u.activo ? 'Desactivar' : 'Activar'}</button></form>
              )}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
