import Link from 'next/link';
import Aviso from '@/components/Aviso';
import { requerSessao } from '@/lib/auth';
import { query } from '@/lib/db';
import { fmtData, kz } from '@/lib/utils';
import type { SP } from '@/types';

export default async function Painel({ searchParams }: { searchParams: SP }) {
  const s = await requerSessao();
  const sp = await searchParams;
  const vende = s.perfil !== 'gestor';
  const filtro = s.perfil === 'vendedor' ? ` AND utilizador_id = ${Number(s.id)}` : '';

  const [hojeV, mesV, baixo, entradas, alertas, ultimas] = await Promise.all([
    vende ? query(`SELECT COALESCE(SUM(total),0) t, COUNT(*) n FROM venda WHERE estado='confirmada' AND DATE(criado_em)=CURDATE()${filtro}`) : [],
    vende ? query(`SELECT COALESCE(SUM(total),0) t FROM venda WHERE estado='confirmada' AND YEAR(criado_em)=YEAR(CURDATE()) AND MONTH(criado_em)=MONTH(CURDATE())${filtro}`) : [],
    query('SELECT COUNT(*) n FROM produto WHERE activo=1 AND stock_actual <= stock_minimo'),
    query('SELECT COUNT(*) n FROM entrada WHERE data_entrada >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)'),
    query('SELECT codigo, nome, stock_actual, stock_minimo FROM produto WHERE activo=1 AND stock_actual <= stock_minimo ORDER BY stock_actual LIMIT 8'),
    vende ? query(`SELECT v.id, v.numero, v.total, v.criado_em, u.nome vendedor FROM venda v JOIN utilizador u ON u.id=v.utilizador_id WHERE v.estado='confirmada'${filtro.replace('utilizador_id', 'v.utilizador_id')} ORDER BY v.id DESC LIMIT 6`) : [],
  ]);

  return (
    <>
      <div className="cabeca"><h1>Painel</h1><span className="mudo">Olá, {s.nome}</span></div>
      <Aviso sp={sp} />
      <div className="grelha">
        {vende && <div className="cartao kpi"><span>Vendas hoje ({hojeV[0].n})</span><b>{kz(hojeV[0].t)}</b></div>}
        {vende && <div className="cartao kpi"><span>Vendas do mês</span><b>{kz(mesV[0].t)}</b></div>}
        <div className="cartao kpi"><span>Produtos em stock baixo</span><b>{baixo[0].n}</b></div>
        {s.perfil !== 'vendedor' && <div className="cartao kpi"><span>Entradas nos últimos 7 dias</span><b>{entradas[0].n}</b></div>}
      </div>
      <div className="duas">
        <div className="cartao">
          <h2>Alertas de stock</h2>
          {alertas.length === 0 ? <p className="mudo">Nenhum produto abaixo do mínimo.</p> : (
            <div className="tabela"><table>
              <thead><tr><th>Produto</th><th>Stock</th><th>Mínimo</th></tr></thead>
              <tbody>{alertas.map((a) => <tr key={a.codigo}><td>{a.nome}</td><td><span className="tag baixo">{a.stock_actual}</span></td><td>{a.stock_minimo}</td></tr>)}</tbody>
            </table></div>
          )}
        </div>
        {vende && (
          <div className="cartao">
            <h2>Últimas vendas</h2>
            {ultimas.length === 0 ? <p className="mudo">Ainda não há vendas.</p> : (
              <div className="tabela"><table>
                <thead><tr><th>Nº</th><th>Data</th><th>Total</th></tr></thead>
                <tbody>{ultimas.map((v) => <tr key={v.id}><td><Link href={`/vendas/${v.id}`}>{v.numero}</Link></td><td>{fmtData(v.criado_em)}</td><td>{kz(v.total)}</td></tr>)}</tbody>
              </table></div>
            )}
          </div>
        )}
      </div>
    </>
  );
}
