import { criarProduto } from '@/actions/produtos';
import Aviso from '@/components/Aviso';
import FormProduto from '@/components/FormProduto';
import { requerPerfil } from '@/lib/auth';
import { query } from '@/lib/db';
import type { SP } from '@/types';

export default async function NovoProduto({ searchParams }: { searchParams: SP }) {
  await requerPerfil(['admin', 'gestor']);
  const sp = await searchParams;
  const categorias = await query('SELECT id, nome, activo FROM categoria WHERE activo = 1 ORDER BY nome');
  return (
    <>
      <h1>Novo produto</h1>
      <Aviso sp={sp} />
      <FormProduto acao={criarProduto} categorias={categorias} />
    </>
  );
}
