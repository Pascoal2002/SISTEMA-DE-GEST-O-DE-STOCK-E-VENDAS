import Link from 'next/link';
import { alternarProduto } from '@/actions/produtos';
import Aviso from '@/components/Aviso';
import Paginacao from '@/components/Paginacao';
import { requerSessao } from '@/lib/auth';
import { query } from '@/lib/db';
import { kz } from '@/lib/utils';
import type { SP } from '@/types';

const POR = 15;

export default async function Produtos({ searchParams }: { searchParams: SP }) {
  const s = await requerSessao();
  const sp = await searchParams;
  const gere = s.perfil !== 'vendedor';
  const q = (sp.q ?? '').trim();
  const cat = Number(sp.categoria) || 0;
  const pagina = Math.max(1, Number(sp.pagina) || 1);

  const cond = ['1=1'];
  const par: unknown[] = [];
  if (q) { cond.push('(p.nome LIKE ? OR p.codigo LIKE ?)'); par.push(`%${q}%`, `%${q}%`); }
  if (cat) { cond.push('p.categoria_id = ?'); par.push(cat); }
  if (!gere) cond.push('p.activo = 1');
  const onde = cond.join(' AND ');

  const [{ n }] = await query(`SELECT COUNT(*) n FROM produto p WHERE ${onde}`, par);
  const [produtos, categorias] = await Promise.all([
    query(`SELECT p.*, c.nome categoria FROM produto p JOIN categoria c ON c.id = p.categoria_id WHERE ${onde} ORDER BY p.nome LIMIT ? OFFSET ?`, [...par, POR, (pagina - 1) * POR]),
    query('SELECT id, nome FROM categoria ORDER BY nome'),
  ]);

  return (
    <>
      <div className="cabeca"><h1>Produtos</h1>{gere && <Link className="btn" href="/produtos/novo">+ Novo produto</Link>}</div>
      <Aviso sp={sp} />
      <form className="cartao filtros" method="get">
        <label>Pesquisar<input name="q" defaultValue={q} placeholder="Nome ou código" /></label>
        <label>Categoria
          <select name="categoria" defaultValue={cat || ''}>
            <option value="">Todas</option>
            {categorias.map((c) => <option key={c.id} value={c.id}>{c.nome}</option>)}
          </select>
        </label>
        <button className="btn">Filtrar</button>
      </form>
      <div className="cartao">
        <div className="tabela"><table>
          <thead><tr><th /><th>Código</th><th>Produto</th><th>Categoria</th><th>Stock</th><th>Preço de venda</th>{gere && <><th>Estado</th><th /></>}</tr></thead>
          <tbody>
            {produtos.length === 0 && <tr><td colSpan={9} className="mudo">Nenhum produto encontrado.</td></tr>}
            {produtos.map((p) => (
              <tr key={p.id}>
                <td>{p.imagem ? <img src={p.imagem} alt="" /> : null}</td>
                <td>{p.codigo}</td><td>{p.nome}</td><td>{p.categoria}</td>
                <td><span className={`tag${p.stock_actual <= p.stock_minimo ? ' baixo' : ''}`}>{p.stock_actual}</span></td>
                <td>{kz(p.preco_venda)}</td>
                {gere && (
                  <>
                    <td>{p.activo ? 'Activo' : 'Inactivo'}</td>
                    <td className="acoes">
                      <Link className="btn sec peq" href={`/produtos/${p.id}`}>Editar</Link>
                      <form action={alternarProduto}><input type="hidden" name="id" value={p.id} /><button className="btn sec peq">{p.activo ? 'Desactivar' : 'Activar'}</button></form>
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table></div>
        <Paginacao rota="/produtos" params={{ q, categoria: cat ? String(cat) : undefined }} pagina={pagina} total={n} por={POR} />
      </div>
    </>
  );
}
