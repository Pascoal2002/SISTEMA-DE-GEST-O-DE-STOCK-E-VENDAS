import { notFound } from 'next/navigation';
import { actualizarProduto } from '@/actions/produtos';
import Aviso from '@/components/Aviso';
import FormProduto from '@/components/FormProduto';
import { requerPerfil } from '@/lib/auth';
import { query } from '@/lib/db';
import type { SP } from '@/types';

export default async function EditarProduto({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: SP }) {
  await requerPerfil(['admin', 'gestor']);
  const { id } = await params;
  const sp = await searchParams;
  const [produto] = await query('SELECT * FROM produto WHERE id = ?', [Number(id) || 0]);
  if (!produto) notFound();
  const categorias = await query('SELECT id, nome, activo FROM categoria ORDER BY nome');
  return (
    <>
      <h1>Editar produto</h1>
      <p className="mudo">Stock actual: <strong>{produto.stock_actual}</strong>. O stock só muda através de entradas, saídas e vendas.</p>
      <Aviso sp={sp} />
      <FormProduto acao={actualizarProduto} categorias={categorias} produto={produto} />
    </>
  );
}
