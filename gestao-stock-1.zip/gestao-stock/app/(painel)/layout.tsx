import type { ReactNode } from 'react';
import { sair } from '@/actions/auth';
import Menu from '@/components/Menu';
import { requerSessao } from '@/lib/auth';
import { MENU, ROTULO_PERFIL } from '@/lib/permissoes';

export default async function PainelLayout({ children }: { children: ReactNode }) {
  const s = await requerSessao();
  const itens = MENU.filter((m) => m.perfis.includes(s.perfil)).map(({ href, nome }) => ({ href, nome }));
  return (
    <>
      <Menu itens={itens} nome={s.nome} perfil={ROTULO_PERFIL[s.perfil]} empresa={process.env.EMPRESA_NOME ?? 'Gestão de Stock'} sair={sair} />
      <main className="conteudo">{children}</main>
    </>
  );
}
