import { entrar } from '@/actions/auth';
import Aviso from '@/components/Aviso';
import type { SP } from '@/types';

export default async function Login({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  return (
    <main className="login">
      <form action={entrar} className="cartao">
        <h1>{process.env.EMPRESA_NOME ?? 'Gestão de Stock'}</h1>
        <p className="mudo">Entre com a sua conta para continuar.</p>
        <Aviso sp={sp} />
        <label>E-mail<input name="email" type="email" required autoComplete="username" /></label>
        <label>Palavra-passe<input name="senha" type="password" required autoComplete="current-password" /></label>
        <button className="btn">Entrar</button>
      </form>
    </main>
  );
}
