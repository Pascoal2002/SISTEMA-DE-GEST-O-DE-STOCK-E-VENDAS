import type { ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { transaccao } from '@/lib/db';
import { ErroNegocio } from '@/lib/erros';
import { agruparItens, movimentar, proximoNumero } from '@/services/stock.service';

/** Confirma a venda e gera as saídas de stock na mesma transacção (RN10). O preço vem SEMPRE da base de dados. */
export async function criarVenda(d: { forma: string; itens: { produto_id: number; quantidade: number }[] }, utilizadorId: number) {
  return transaccao(async (c) => {
    const numero = await proximoNumero(c, 'VD');
    const [r] = await c.query<ResultSetHeader>(
      'INSERT INTO venda (numero, utilizador_id, forma_pagamento, total) VALUES (?,?,?,0)', [numero, utilizadorId, d.forma]);
    let total = 0;
    for (const i of agruparItens(d.itens)) {
      const p = await movimentar(c, { produtoId: i.produto_id, tipo: 'saida', motivo: 'venda', quantidade: i.quantidade, utilizadorId, refTipo: 'venda', refId: r.insertId });
      if (!p.activo) throw new ErroNegocio(`O produto "${p.nome}" está desactivado.`);
      const subtotal = Number(p.preco_venda) * i.quantidade; // RN11: preço gravado no item
      total += subtotal;
      await c.query('INSERT INTO item_venda (venda_id, produto_id, quantidade, preco_unitario, subtotal) VALUES (?,?,?,?,?)',
        [r.insertId, i.produto_id, i.quantidade, p.preco_venda, subtotal]);
    }
    await c.query('UPDATE venda SET total = ? WHERE id = ?', [total, r.insertId]);
    return r.insertId;
  });
}

/** Anula a venda sem a apagar e repõe o stock com movimentos de estorno (RN12). */
export async function anularVenda(id: number, utilizadorId: number) {
  return transaccao(async (c) => {
    const [v] = await c.query<RowDataPacket[]>('SELECT id, estado FROM venda WHERE id = ? FOR UPDATE', [id]);
    if (!v[0]) throw new ErroNegocio('Venda não encontrada.');
    if (v[0].estado === 'anulada') throw new ErroNegocio('Esta venda já foi anulada.');
    const [itens] = await c.query<RowDataPacket[]>('SELECT produto_id, quantidade FROM item_venda WHERE venda_id = ?', [id]);
    for (const i of agruparItens(itens as { produto_id: number; quantidade: number }[])) {
      await movimentar(c, { produtoId: i.produto_id, tipo: 'entrada', motivo: 'estorno_venda', quantidade: i.quantidade, utilizadorId, refTipo: 'venda', refId: id });
    }
    await c.query("UPDATE venda SET estado = 'anulada', anulada_em = NOW(), anulada_por = ? WHERE id = ?", [utilizadorId, id]);
  });
}
