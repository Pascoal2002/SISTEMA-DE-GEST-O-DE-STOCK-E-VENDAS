import type { PoolConnection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { transaccao } from '@/lib/db';
import { ErroNegocio } from '@/lib/erros';

/** Numeração sequencial por ano, ex.: VD-2026-0001 (atómica dentro da transacção). */
export async function proximoNumero(c: PoolConnection, prefixo: string) {
  const ano = new Date().getFullYear();
  await c.query('INSERT INTO sequencia (nome, ano, ultimo) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE ultimo = ultimo + 1', [prefixo, ano]);
  const [r] = await c.query<RowDataPacket[]>('SELECT ultimo FROM sequencia WHERE nome = ? AND ano = ?', [prefixo, ano]);
  return `${prefixo}-${ano}-${String(r[0].ultimo).padStart(4, '0')}`;
}

export type Movimento = {
  produtoId: number;
  tipo: 'entrada' | 'saida';
  motivo: string;
  quantidade: number;
  utilizadorId: number;
  refTipo?: string;
  refId?: number;
  obs?: string;
};

/**
 * ÚNICO ponto onde o stock muda (RN01). Bloqueia a linha do produto, impede stock negativo (RN02)
 * e regista o movimento com o stock resultante.
 */
export async function movimentar(c: PoolConnection, m: Movimento) {
  if (!Number.isInteger(m.quantidade) || m.quantidade <= 0) throw new ErroNegocio('Quantidade inválida.');
  const [rows] = await c.query<RowDataPacket[]>(
    'SELECT id, nome, activo, preco_venda, stock_actual FROM produto WHERE id = ? FOR UPDATE', [m.produtoId]);
  const p = rows[0];
  if (!p) throw new ErroNegocio('Produto não encontrado.');
  const novo = p.stock_actual + (m.tipo === 'entrada' ? m.quantidade : -m.quantidade);
  if (novo < 0) throw new ErroNegocio(`Stock insuficiente para "${p.nome}" (disponível: ${p.stock_actual}).`);
  await c.query('UPDATE produto SET stock_actual = ? WHERE id = ?', [novo, m.produtoId]);
  await c.query(
    `INSERT INTO movimento_stock (produto_id, tipo, motivo, quantidade, stock_apos, referencia_tipo, referencia_id, observacao, utilizador_id)
     VALUES (?,?,?,?,?,?,?,?,?)`,
    [m.produtoId, m.tipo, m.motivo, m.quantidade, novo, m.refTipo ?? null, m.refId ?? null, m.obs ?? null, m.utilizadorId]);
  return p;
}

/** Junta linhas repetidas do mesmo produto e ordena por id (evita bloqueios cruzados). */
export function agruparItens<T extends { produto_id: number; quantidade: number }>(itens: T[]): T[] {
  const mapa = new Map<number, T>();
  for (const i of itens) {
    const x = mapa.get(i.produto_id);
    if (x) x.quantidade += i.quantidade; else mapa.set(i.produto_id, { ...i });
  }
  return [...mapa.values()].sort((a, b) => a.produto_id - b.produto_id);
}

export async function registarEntrada(
  d: { fornecedorId: number; data: string; documento?: string; itens: { produto_id: number; quantidade: number; preco: number }[] },
  utilizadorId: number,
) {
  return transaccao(async (c) => {
    const [f] = await c.query<RowDataPacket[]>('SELECT activo FROM fornecedor WHERE id = ?', [d.fornecedorId]);
    if (!f[0] || !f[0].activo) throw new ErroNegocio('Fornecedor inválido ou inactivo.');
    const itens = agruparItens(d.itens);
    const total = itens.reduce((s, i) => s + i.quantidade * i.preco, 0);
    const numero = await proximoNumero(c, 'EN');
    const [r] = await c.query<ResultSetHeader>(
      'INSERT INTO entrada (numero, fornecedor_id, data_entrada, documento, total, utilizador_id) VALUES (?,?,?,?,?,?)',
      [numero, d.fornecedorId, d.data, d.documento || null, total, utilizadorId]);
    for (const i of itens) {
      await movimentar(c, { produtoId: i.produto_id, tipo: 'entrada', motivo: 'compra', quantidade: i.quantidade, utilizadorId, refTipo: 'entrada', refId: r.insertId });
      await c.query('INSERT INTO item_entrada (entrada_id, produto_id, quantidade, preco_custo) VALUES (?,?,?,?)', [r.insertId, i.produto_id, i.quantidade, i.preco]);
      await c.query('UPDATE produto SET preco_compra = ? WHERE id = ?', [i.preco, i.produto_id]); // último preço de compra
    }
    return r.insertId;
  });
}

export async function registarSaida(
  d: { motivo: string; obs?: string; itens: { produto_id: number; quantidade: number }[] },
  utilizadorId: number,
) {
  return transaccao(async (c) => {
    for (const i of agruparItens(d.itens)) {
      await movimentar(c, { produtoId: i.produto_id, tipo: 'saida', motivo: d.motivo, quantidade: i.quantidade, utilizadorId, obs: d.obs });
    }
  });
}
