import { query } from '@/lib/db';
import type { Perfil } from '@/types';

export type Fmt = 'texto' | 'kz' | 'num' | 'data';
export type Resultado = { colunas: string[]; fmt: Fmt[]; linhas: (string | number)[][] };

export const TIPOS: { id: string; nome: string; perfis: Perfil[]; periodo: boolean }[] = [
  { id: 'stock_actual', nome: 'Stock actual', perfis: ['admin', 'gestor'], periodo: false },
  { id: 'stock_baixo', nome: 'Produtos abaixo do mínimo', perfis: ['admin', 'gestor'], periodo: false },
  { id: 'movimentos', nome: 'Movimentos de stock', perfis: ['admin', 'gestor'], periodo: true },
  { id: 'compras_fornecedor', nome: 'Compras por fornecedor', perfis: ['admin', 'gestor'], periodo: true },
  { id: 'vendas_periodo', nome: 'Vendas por dia', perfis: ['admin'], periodo: true },
  { id: 'mais_vendidos', nome: 'Produtos mais vendidos', perfis: ['admin'], periodo: true },
];

const ISO = /^\d{4}-\d{2}-\d{2}$/;

export async function gerar(tipo: string, de: string, ate: string): Promise<Resultado> {
  const d = ISO.test(de) ? de : '1970-01-01';
  const a = ISO.test(ate) ? ate : '2999-12-31';

  switch (tipo) {
    case 'stock_actual':
    case 'stock_baixo': {
      const r = await query(
        `SELECT p.codigo, p.nome, c.nome categoria, p.stock_actual, p.stock_minimo, p.stock_actual * p.preco_compra valor
         FROM produto p JOIN categoria c ON c.id = p.categoria_id
         WHERE p.activo = 1 ${tipo === 'stock_baixo' ? 'AND p.stock_actual <= p.stock_minimo' : ''} ORDER BY p.nome`);
      return {
        colunas: ['Código', 'Produto', 'Categoria', 'Stock', 'Mínimo', 'Valor em stock'],
        fmt: ['texto', 'texto', 'texto', 'num', 'num', 'kz'],
        linhas: r.map((x) => [x.codigo, x.nome, x.categoria, x.stock_actual, x.stock_minimo, Number(x.valor)]),
      };
    }
    case 'movimentos': {
      const r = await query(
        `SELECT m.criado_em, p.nome produto, m.tipo, m.motivo, m.quantidade, m.stock_apos, u.nome utilizador
         FROM movimento_stock m JOIN produto p ON p.id = m.produto_id JOIN utilizador u ON u.id = m.utilizador_id
         WHERE DATE(m.criado_em) BETWEEN ? AND ? ORDER BY m.id DESC LIMIT 1000`, [d, a]);
      return {
        colunas: ['Data', 'Produto', 'Tipo', 'Motivo', 'Quantidade', 'Stock após', 'Utilizador'],
        fmt: ['data', 'texto', 'texto', 'texto', 'num', 'num', 'texto'],
        linhas: r.map((x) => [x.criado_em, x.produto, x.tipo === 'entrada' ? 'Entrada' : 'Saída', x.motivo, x.quantidade, x.stock_apos, x.utilizador]),
      };
    }
    case 'compras_fornecedor': {
      const r = await query(
        `SELECT f.nome, COUNT(e.id) n, COALESCE(SUM(e.total), 0) total
         FROM entrada e JOIN fornecedor f ON f.id = e.fornecedor_id
         WHERE e.data_entrada BETWEEN ? AND ? GROUP BY f.id, f.nome ORDER BY total DESC`, [d, a]);
      return {
        colunas: ['Fornecedor', 'Nº de entradas', 'Total comprado'],
        fmt: ['texto', 'num', 'kz'],
        linhas: r.map((x) => [x.nome, x.n, Number(x.total)]),
      };
    }
    case 'vendas_periodo': {
      const r = await query(
        `SELECT DATE(criado_em) dia, COUNT(*) n, SUM(total) total FROM venda
         WHERE estado = 'confirmada' AND DATE(criado_em) BETWEEN ? AND ? GROUP BY dia ORDER BY dia`, [d, a]);
      return {
        colunas: ['Dia', 'Nº de vendas', 'Total vendido'],
        fmt: ['data', 'num', 'kz'],
        linhas: r.map((x) => [x.dia, x.n, Number(x.total)]),
      };
    }
    case 'mais_vendidos': {
      const r = await query(
        `SELECT p.codigo, p.nome, SUM(i.quantidade) qtd, SUM(i.subtotal) total
         FROM item_venda i JOIN venda v ON v.id = i.venda_id JOIN produto p ON p.id = i.produto_id
         WHERE v.estado = 'confirmada' AND DATE(v.criado_em) BETWEEN ? AND ?
         GROUP BY p.id, p.codigo, p.nome ORDER BY qtd DESC LIMIT 50`, [d, a]);
      return {
        colunas: ['Código', 'Produto', 'Unidades vendidas', 'Total'],
        fmt: ['texto', 'texto', 'num', 'kz'],
        linhas: r.map((x) => [x.codigo, x.nome, Number(x.qtd), Number(x.total)]),
      };
    }
    default:
      return { colunas: [], fmt: [], linhas: [] };
  }
}
