import type { NextConfig } from 'next';

const config: NextConfig = {
  // Permite o envio de imagens de produtos (até 2 MB) nos formulários.
  experimental: { serverActions: { bodySizeLimit: '3mb' } },
};

export default config;
