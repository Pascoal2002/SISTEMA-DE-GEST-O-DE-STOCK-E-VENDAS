import { redirect } from 'next/navigation';
import { ZodError } from 'zod';

/** Erro previsto pelas regras de negócio (a mensagem é mostrada ao utilizador). */
export class ErroNegocio extends Error {}

export function mensagemErro(e: unknown): string {
  if (e instanceof ZodError) return e.issues[0]?.message ?? 'Dados inválidos.';
  if (e instanceof ErroNegocio) return e.message;
  if ((e as { code?: string })?.code === 'ER_DUP_ENTRY') return 'Já existe um registo com este valor (código, e-mail ou nome).';
  console.error(e);
  return 'Ocorreu um erro inesperado. Tente novamente.';
}

const comMsg = (url: string, chave: 'ok' | 'erro', msg?: string) =>
  msg ? `${url}${url.includes('?') ? '&' : '?'}${chave}=${encodeURIComponent(msg)}` : url;

/**
 * Corre a acção. Sucesso: vai para `ok` (ou para o endereço devolvido por `fn`) com a mensagem `msgOk`.
 * Erro: volta a `falha` com a mensagem de erro.
 */
export async function executar(fn: () => Promise<string | void>, ok: string, falha: string, msgOk?: string): Promise<never> {
  let destino: string;
  try {
    const url = await fn();
    destino = comMsg(url || ok, 'ok', msgOk);
  } catch (e) {
    destino = comMsg(falha, 'erro', mensagemErro(e));
  }
  redirect(destino);
}

export const semPermissao = () => redirect(comMsg('/dashboard', 'erro', 'Não tem permissão para esta acção.'));
