import type { Perfil } from '@/types';

const TODOS: Perfil[] = ['admin', 'gestor', 'vendedor'];

export const MENU: { href: string; nome: string; perfis: Perfil[] }[] = [
  { href: '/dashboard', nome: 'Painel', perfis: TODOS },
  { href: '/produtos', nome: 'Produtos', perfis: TODOS },
  { href: '/categorias', nome: 'Categorias', perfis: ['admin', 'gestor'] },
  { href: '/fornecedores', nome: 'Fornecedores', perfis: ['admin', 'gestor'] },
  { href: '/entradas', nome: 'Entradas', perfis: ['admin', 'gestor'] },
  { href: '/saidas', nome: 'Saídas', perfis: ['admin', 'gestor'] },
  { href: '/vendas', nome: 'Vendas', perfis: ['admin', 'vendedor'] },
  { href: '/consultas', nome: 'Consultas', perfis: TODOS },
  { href: '/relatorios', nome: 'Relatórios', perfis: ['admin', 'gestor'] },
  { href: '/utilizadores', nome: 'Utilizadores', perfis: ['admin'] },
];

export const ROTULO_PERFIL: Record<Perfil, string> = { admin: 'Administrador', gestor: 'Gestor de stock', vendedor: 'Vendedor' };
