export const kz = (n: unknown) =>
  Number(n ?? 0).toLocaleString('pt-PT', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' Kz';

/** "2026-11-16 14:30:00" -> "16/11/2026 14:30" */
export function fmtData(s?: string | null) {
  if (!s) return '—';
  const [d, h] = s.split(/[ T]/);
  const [a, m, dia] = d.split('-');
  return `${dia}/${m}/${a}${h ? ' ' + h.slice(0, 5) : ''}`;
}

export const hoje = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
export const inicioMes = () => hoje().slice(0, 8) + '01';

export function formatar(v: unknown, fmt: 'texto' | 'kz' | 'num' | 'data') {
  if (fmt === 'kz') return kz(v);
  if (fmt === 'num') return Number(v).toLocaleString('pt-PT');
  if (fmt === 'data') return fmtData(String(v));
  return String(v ?? '');
}

export const ROTULO_MOTIVO: Record<string, string> = {
  compra: 'Compra', venda: 'Venda', perda: 'Perda', avaria: 'Avaria',
  devolucao_fornecedor: 'Devolução ao fornecedor', ajuste: 'Ajuste', estorno_venda: 'Estorno de venda',
};
export const ROTULO_PAGAMENTO: Record<string, string> = { numerario: 'Numerário', tpa: 'TPA', transferencia: 'Transferência' };
