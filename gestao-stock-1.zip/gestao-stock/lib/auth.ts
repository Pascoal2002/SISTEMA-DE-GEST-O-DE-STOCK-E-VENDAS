import { cache } from 'react';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { SignJWT, jwtVerify } from 'jose';
import { query } from '@/lib/db';
import { semPermissao } from '@/lib/erros';
import type { Perfil } from '@/types';

export type Sessao = { id: number; nome: string; perfil: Perfil };
const COOKIE = 'sessao';
const chave = () => new TextEncoder().encode(process.env.AUTH_SECRET ?? '');

export async function criarSessao(s: Sessao) {
  const token = await new SignJWT({ ...s }).setProtectedHeader({ alg: 'HS256' }).setExpirationTime('8h').sign(chave());
  (await cookies()).set(COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 60 * 60 * 8,
  });
}

export async function terminarSessao() {
  (await cookies()).delete(COOKIE);
}

export async function obterSessao(): Promise<Sessao | null> {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, chave());
    return { id: Number(payload.id), nome: String(payload.nome), perfil: payload.perfil as Perfil };
  } catch {
    return null;
  }
}

const aindaActivo = cache(async (id: number) => (await query('SELECT activo FROM utilizador WHERE id = ?', [id]))[0]?.activo === 1);

/** Exige sessão válida e utilizador activo (um utilizador desactivado perde o acesso de imediato). */
export async function requerSessao(): Promise<Sessao> {
  const s = await obterSessao();
  if (!s || !(await aindaActivo(s.id))) redirect('/login');
  return s;
}

/** Controlo de acesso por perfil, aplicado no servidor. */
export async function requerPerfil(perfis: Perfil[]): Promise<Sessao> {
  const s = await requerSessao();
  if (!perfis.includes(s.perfil)) semPermissao();
  return s;
}
