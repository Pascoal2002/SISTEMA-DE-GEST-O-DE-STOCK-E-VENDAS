import { z } from 'zod';

const num = (msg: string) => z.coerce.number({ invalid_type_error: msg });
const dinheiro = num('Valor inválido.').min(0, 'O valor não pode ser negativo.');
const texto = (max = 200) => z.string().trim().max(max, 'Texto demasiado longo.').optional().transform((v) => v || null);

export const produtoSchema = z.object({
  codigo: z.string().trim().min(1, 'Indique o código do produto.').max(30),
  nome: z.string().trim().min(2, 'Indique o nome do produto.').max(150),
  descricao: texto(500),
  categoria_id: num('Escolha a categoria.').int().positive('Escolha a categoria.'),
  preco_compra: dinheiro,
  preco_venda: dinheiro,
  stock_minimo: num('Stock mínimo inválido.').int('Stock mínimo inválido.').min(0, 'Stock mínimo inválido.'),
});

export const fornecedorSchema = z.object({
  nome: z.string().trim().min(2, 'Indique o nome do fornecedor.').max(150),
  nif: texto(30),
  telefone: texto(30),
  email: z.string().trim().max(150).optional().transform((v) => v || null)
    .refine((v) => !v || /^\S+@\S+\.\S+$/.test(v), 'E-mail inválido.'),
  endereco: texto(255),
});

export const utilizadorSchema = z.object({
  nome: z.string().trim().min(2, 'Indique o nome.').max(120),
  email: z.string().trim().toLowerCase().email('E-mail inválido.'),
  perfil: z.enum(['admin', 'gestor', 'vendedor'], { errorMap: () => ({ message: 'Perfil inválido.' }) }),
});

export const senhaSchema = z.string().min(8, 'A palavra-passe deve ter pelo menos 8 caracteres.').max(100);
export const dataSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Data inválida.');
export const idSchema = z.coerce.number().int().positive('Registo inválido.');

const item = z.object({
  produto_id: z.number().int().positive(),
  quantidade: z.number({ invalid_type_error: 'Quantidade inválida.' }).int('Quantidade inválida.').positive('Quantidade inválida.'),
  preco: z.number().min(0, 'Preço inválido.').optional(),
});

/** Lê a lista de produtos enviada pelo seletor (campo "itens", em JSON). */
export function lerItens(fd: FormData) {
  let bruto: unknown = [];
  try { bruto = JSON.parse(String(fd.get('itens') ?? '[]')); } catch {}
  return z.array(item).min(1, 'Adicione pelo menos um produto.').parse(bruto);
}
