import mysql from 'mysql2/promise';
import type { Pool, PoolConnection } from 'mysql2/promise';

const g = globalThis as unknown as { _pool?: Pool };

export const pool: Pool =
  g._pool ??
  mysql.createPool({
    host: process.env.DB_HOST ?? 'localhost',
    port: Number(process.env.DB_PORT ?? 3306),
    user: process.env.DB_USER ?? 'root',
    password: process.env.DB_PASSWORD ?? '',
    database: process.env.DB_NAME ?? 'gestao_stock',
    waitForConnections: true,
    connectionLimit: 10,
    dateStrings: true,
    charset: 'utf8mb4',
  });
if (process.env.NODE_ENV !== 'production') g._pool = pool;

/** Consulta parametrizada (os valores nunca são concatenados no SQL). */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function query<T = any>(sql: string, params: unknown[] = []): Promise<T[]> {
  const [rows] = await pool.query(sql, params);
  return rows as unknown as T[];
}

/** Executa várias operações como uma só: ou tudo é gravado, ou nada. */
export async function transaccao<T>(fn: (c: PoolConnection) => Promise<T>): Promise<T> {
  const c = await pool.getConnection();
  try {
    await c.beginTransaction();
    const r = await fn(c);
    await c.commit();
    return r;
  } catch (e) {
    await c.rollback();
    throw e;
  } finally {
    c.release();
  }
}
