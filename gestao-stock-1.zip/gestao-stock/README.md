# Gestão de Stock e Vendas

Sistema web (computador e telemóvel) para gerir produtos, fornecedores, entradas e saídas de stock, vendas, consultas e relatórios.
Stack: **Next.js (App Router) + React + TypeScript + MySQL**.

## Como executar

Requisitos: Node.js 20.6 ou superior e MySQL 8.

1. `npm install`
2. Copie `.env.example` para `.env.local` e preencha os dados do MySQL e o `AUTH_SECRET`
   (gere uma chave com: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`).
3. `npm run db:init` — cria a base de dados, as tabelas e o administrador inicial.
4. `npm run dev` — abra http://localhost:3000

Administrador inicial: o e-mail e a palavra-passe definidos em `ADMIN_EMAIL` e `ADMIN_SENHA` (por omissão `admin@empresa.ao` / `Admin@12345`). Altere a palavra-passe em Utilizadores.

Para produção: `npm run build` e `npm start`.

## Primeiros passos de uso

1. Categorias → crie as categorias. 2. Fornecedores → registe um fornecedor. 3. Produtos → registe os produtos.
4. Entradas → registe a primeira entrada (é assim que o produto ganha stock). 5. Vendas → faça uma venda.

## Perfis

- **Administrador**: tudo, incluindo utilizadores, anulação de vendas e relatórios financeiros.
- **Gestor de stock**: produtos, categorias, fornecedores, entradas, saídas, consultas e relatórios de stock.
- **Vendedor**: vendas (só vê as suas), consulta de produtos e de stock.

## Estrutura

```
app/(auth)/login        Início de sessão
app/(painel)/...        Páginas protegidas (dashboard, produtos, categorias, fornecedores, entradas, saidas, vendas, consultas, relatorios, utilizadores)
app/api/relatorios/csv  Exportação CSV
actions/                Server Actions (recebem os formulários, validam e chamam os serviços)
services/               Regras de negócio e transacções (stock, vendas, relatórios)
lib/                    Base de dados, autenticação, validações, permissões, utilitários
components/             Componentes reutilizáveis (menu responsivo, seletor de produtos, formulários)
database/schema.sql     Esquema MySQL
scripts/init-db.mjs     Criação da base de dados e do administrador
proxy.ts                Protecção das rotas (substitui o middleware.ts no Next.js 16)
```

## Regras principais

- O stock só muda através de movimentos (entrada, saída, venda, estorno) e nunca fica negativo.
- Cada venda e cada entrada têm número sequencial (VD-2026-0001, EN-2026-0001).
- Vendas anuladas não são apagadas: ficam registadas e o stock é reposto por movimentos de estorno.
- Produtos, fornecedores e utilizadores nunca são eliminados, apenas desactivados.
- O preço de uma venda é sempre lido da base de dados e gravado no item da venda.
