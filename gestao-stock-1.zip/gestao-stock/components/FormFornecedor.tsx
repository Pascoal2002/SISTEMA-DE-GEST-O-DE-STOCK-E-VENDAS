import Link from 'next/link';
import type { Row } from '@/types';

export default function FormFornecedor({ acao, fornecedor }: { acao: (fd: FormData) => Promise<void>; fornecedor?: Row }) {
  return (
    <form action={acao} className="cartao form">
      {fornecedor && <input type="hidden" name="id" value={fornecedor.id} />}
      <label>Nome<input name="nome" required maxLength={150} defaultValue={fornecedor?.nome} /></label>
      <label>NIF<input name="nif" maxLength={30} defaultValue={fornecedor?.nif ?? ''} /></label>
      <label>Telefone<input name="telefone" type="tel" maxLength={30} defaultValue={fornecedor?.telefone ?? ''} /></label>
      <label>E-mail<input name="email" type="email" maxLength={150} defaultValue={fornecedor?.email ?? ''} /></label>
      <label className="larga">Endereço<input name="endereco" maxLength={255} defaultValue={fornecedor?.endereco ?? ''} /></label>
      <div className="larga acoes"><button className="btn">Guardar</button><Link className="btn sec" href="/fornecedores">Cancelar</Link></div>
    </form>
  );
}
