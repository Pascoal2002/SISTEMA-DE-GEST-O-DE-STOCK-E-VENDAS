'use client';
import type { ReactNode } from 'react';

export function BotaoImprimir({ children = 'Imprimir / PDF' }: { children?: ReactNode }) {
  return <button type="button" className="btn sec nao-imprimir" onClick={() => window.print()}>{children}</button>;
}

export function BotaoConfirmar({ mensagem, children, className = 'btn perigo' }: { mensagem: string; children: ReactNode; className?: string }) {
  return <button className={className} onClick={(e) => { if (!confirm(mensagem)) e.preventDefault(); }}>{children}</button>;
}
