import Link from 'next/link';

export default function Paginacao({ rota, params, pagina, total, por }: {
  rota: string; params: Record<string, string | undefined>; pagina: number; total: number; por: number;
}) {
  const n = Math.max(1, Math.ceil(total / por));
  if (n <= 1) return null;
  const href = (p: number) => {
    const u = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v) u.set(k, v);
    u.set('pagina', String(p));
    return `${rota}?${u}`;
  };
  return (
    <div className="pagina nao-imprimir">
      {pagina > 1 && <Link className="btn sec" href={href(pagina - 1)}>← Anterior</Link>}
      <span>Página {pagina} de {n}</span>
      {pagina < n && <Link className="btn sec" href={href(pagina + 1)}>Seguinte →</Link>}
    </div>
  );
}
