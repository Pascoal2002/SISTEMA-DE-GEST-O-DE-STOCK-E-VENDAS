import Link from 'next/link';
import type { Row } from '@/types';

export default function FormProduto({ acao, categorias, produto }: {
  acao: (fd: FormData) => Promise<void>; categorias: Row[]; produto?: Row;
}) {
  return (
    <form action={acao} className="cartao form">
      {produto && <input type="hidden" name="id" value={produto.id} />}
      <label>Código<input name="codigo" required maxLength={30} defaultValue={produto?.codigo} /></label>
      <label>Nome<input name="nome" required maxLength={150} defaultValue={produto?.nome} /></label>
      <label>Categoria
        <select name="categoria_id" required defaultValue={produto?.categoria_id ?? ''}>
          <option value="" disabled>Escolha…</option>
          {categorias.map((c) => <option key={c.id} value={c.id}>{c.nome}{c.activo ? '' : ' (inactiva)'}</option>)}
        </select>
      </label>
      <label>Preço de compra (Kz)<input name="preco_compra" type="number" step="0.01" min="0" required defaultValue={produto?.preco_compra ?? 0} /></label>
      <label>Preço de venda (Kz)<input name="preco_venda" type="number" step="0.01" min="0" required defaultValue={produto?.preco_venda ?? 0} /></label>
      <label>Stock mínimo<input name="stock_minimo" type="number" step="1" min="0" required defaultValue={produto?.stock_minimo ?? 0} /></label>
      <label className="larga">Imagem (JPG, PNG ou WEBP, até 2 MB)
        <input name="imagem" type="file" accept="image/jpeg,image/png,image/webp" />
      </label>
      <label className="larga">Descrição<textarea name="descricao" rows={3} maxLength={500} defaultValue={produto?.descricao ?? ''} /></label>
      <div className="larga acoes"><button className="btn">Guardar</button><Link className="btn sec" href="/produtos">Cancelar</Link></div>
    </form>
  );
}
