export default function Aviso({ sp }: { sp: Record<string, string | undefined> }) {
  if (sp.erro) return <div className="aviso erro" role="alert">{sp.erro}</div>;
  if (sp.ok) return <div className="aviso ok" role="status">{sp.ok}</div>;
  return null;
}
