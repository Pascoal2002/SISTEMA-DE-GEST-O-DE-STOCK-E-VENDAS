'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';

type Item = { href: string; nome: string };

/** Menu lateral no computador; no telemóvel abre como gaveta a partir do botão ☰. */
export default function Menu({ itens, nome, perfil, empresa, sair }: {
  itens: Item[]; nome: string; perfil: string; empresa: string; sair: () => Promise<void>;
}) {
  const [aberto, setAberto] = useState(false);
  const caminho = usePathname();
  return (
    <>
      <header className="topo nao-imprimir">
        <button className="btn sec" aria-label="Abrir menu" onClick={() => setAberto(true)}>☰</button>
        <strong>{empresa}</strong>
      </header>
      {aberto && <div className="fundo" onClick={() => setAberto(false)} />}
      <aside className={`lateral nao-imprimir${aberto ? ' aberta' : ''}`}>
        <div className="marca">{empresa}</div>
        <nav>
          {itens.map((i) => (
            <Link key={i.href} href={i.href} onClick={() => setAberto(false)} className={caminho.startsWith(i.href) ? 'activo' : ''}>
              {i.nome}
            </Link>
          ))}
        </nav>
        <div className="utilizador">
          <span>{nome}</span>
          <small>{perfil}</small>
          <form action={sair}><button className="btn sec peq">Terminar sessão</button></form>
        </div>
      </aside>
    </>
  );
}
