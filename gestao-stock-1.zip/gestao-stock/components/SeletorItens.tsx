'use client';
import { useState } from 'react';

type P = { id: number; codigo: string; nome: string; stock_actual: number; preco_compra: number; preco_venda: number };
type L = { produto_id: number; quantidade: number; preco: number };

const kz = (n: number) => n.toLocaleString('pt-PT', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' Kz';

/**
 * Seletor de produtos usado em entradas, saídas e vendas.
 * Envia as linhas no campo escondido "itens" (JSON). Na venda o preço mostrado é só informativo:
 * o servidor volta a ler o preço da base de dados.
 */
export default function SeletorItens({ produtos, modo, rotulo }: {
  produtos: P[]; modo: 'entrada' | 'venda' | 'saida'; rotulo: string;
}) {
  const [q, setQ] = useState('');
  const [linhas, setLinhas] = useState<L[]>([]);
  const porId = new Map(produtos.map((p) => [p.id, p]));
  const precoBase = (p: P) => (modo === 'venda' ? p.preco_venda : p.preco_compra);

  const termo = q.trim().toLowerCase();
  const sugestoes = termo
    ? produtos.filter((p) => `${p.nome} ${p.codigo}`.toLowerCase().includes(termo) && !linhas.some((l) => l.produto_id === p.id)).slice(0, 6)
    : [];

  const adicionar = (p: P) => { setLinhas([...linhas, { produto_id: p.id, quantidade: 1, preco: precoBase(p) }]); setQ(''); };
  const editar = (i: number, c: Partial<L>) => setLinhas(linhas.map((l, k) => (k === i ? { ...l, ...c } : l)));
  const total = linhas.reduce((s, l) => s + l.quantidade * l.preco, 0);

  return (
    <div className="seletor">
      <label>
        Adicionar produto
        <input
          value={q} onChange={(e) => setQ(e.target.value)} placeholder="Pesquisar por nome ou código" autoComplete="off"
          onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); if (sugestoes[0]) adicionar(sugestoes[0]); } }}
        />
      </label>
      {sugestoes.length > 0 && (
        <ul className="sugestoes">
          {sugestoes.map((p) => (
            <li key={p.id}>
              <button type="button" className="btn sec" onClick={() => adicionar(p)}>
                {p.nome} <small>({p.codigo}) · stock {p.stock_actual}</small>
              </button>
            </li>
          ))}
        </ul>
      )}

      {linhas.length === 0 ? <p className="mudo">Ainda não adicionou produtos.</p> : (
        <div className="tabela">
          <table>
            <thead><tr><th>Produto</th><th>Qtd</th>{modo !== 'saida' && <th>Preço</th>}{modo !== 'saida' && <th>Subtotal</th>}<th /></tr></thead>
            <tbody>
              {linhas.map((l, i) => {
                const p = porId.get(l.produto_id)!;
                return (
                  <tr key={l.produto_id}>
                    <td>{p.nome}<br /><small className="mudo">stock {p.stock_actual}</small></td>
                    <td>
                      <input className="peq" type="number" min={1} step={1} value={l.quantidade} aria-label={`Quantidade de ${p.nome}`}
                        onChange={(e) => editar(i, { quantidade: Math.max(1, Math.floor(Number(e.target.value) || 1)) })} />
                    </td>
                    {modo === 'entrada' && (
                      <td><input className="med" type="number" min={0} step="0.01" value={l.preco} aria-label={`Preço de custo de ${p.nome}`}
                        onChange={(e) => editar(i, { preco: Math.max(0, Number(e.target.value) || 0) })} /></td>
                    )}
                    {modo === 'venda' && <td>{kz(l.preco)}</td>}
                    {modo !== 'saida' && <td>{kz(l.quantidade * l.preco)}</td>}
                    <td><button type="button" className="btn sec peq" onClick={() => setLinhas(linhas.filter((_, k) => k !== i))}>Remover</button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <input type="hidden" name="itens" value={JSON.stringify(linhas)} />
      {modo !== 'saida' && <p className="total">Total: <strong>{kz(total)}</strong></p>}
      <button className="btn" disabled={linhas.length === 0}>{rotulo}</button>
    </div>
  );
}
