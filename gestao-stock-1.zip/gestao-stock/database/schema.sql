-- Gestão de Stock e Vendas — esquema MySQL 8 (utf8mb4)
-- Executado por "npm run db:init" (ou importe manualmente numa base de dados vazia).

CREATE TABLE IF NOT EXISTS utilizador (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  perfil ENUM('admin','gestor','vendedor') NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categoria (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL UNIQUE,
  activo TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS produto (
  id INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(30) NOT NULL UNIQUE,
  nome VARCHAR(150) NOT NULL,
  descricao VARCHAR(500) NULL,
  categoria_id INT NOT NULL,
  preco_compra DECIMAL(12,2) NOT NULL DEFAULT 0,
  preco_venda DECIMAL(12,2) NOT NULL DEFAULT 0,
  stock_minimo INT NOT NULL DEFAULT 0,
  -- Valor derivado dos movimentos: só é alterado dentro de transacções (services/stock.service.ts)
  stock_actual INT NOT NULL DEFAULT 0,
  imagem VARCHAR(255) NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_stock CHECK (stock_actual >= 0),
  CONSTRAINT fk_produto_categoria FOREIGN KEY (categoria_id) REFERENCES categoria(id),
  INDEX idx_produto_nome (nome)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS fornecedor (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  nif VARCHAR(30) NULL,
  telefone VARCHAR(30) NULL,
  email VARCHAR(150) NULL,
  endereco VARCHAR(255) NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sequencia (
  nome VARCHAR(10) NOT NULL,
  ano INT NOT NULL,
  ultimo INT NOT NULL DEFAULT 0,
  PRIMARY KEY (nome, ano)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS entrada (
  id INT AUTO_INCREMENT PRIMARY KEY,
  numero VARCHAR(20) NOT NULL UNIQUE,
  fornecedor_id INT NOT NULL,
  data_entrada DATE NOT NULL,
  documento VARCHAR(60) NULL,
  total DECIMAL(14,2) NOT NULL DEFAULT 0,
  utilizador_id INT NOT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (fornecedor_id) REFERENCES fornecedor(id),
  FOREIGN KEY (utilizador_id) REFERENCES utilizador(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS item_entrada (
  id INT AUTO_INCREMENT PRIMARY KEY,
  entrada_id INT NOT NULL,
  produto_id INT NOT NULL,
  quantidade INT NOT NULL,
  preco_custo DECIMAL(12,2) NOT NULL,
  FOREIGN KEY (entrada_id) REFERENCES entrada(id),
  FOREIGN KEY (produto_id) REFERENCES produto(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS venda (
  id INT AUTO_INCREMENT PRIMARY KEY,
  numero VARCHAR(20) NOT NULL UNIQUE,
  utilizador_id INT NOT NULL,
  forma_pagamento ENUM('numerario','tpa','transferencia') NOT NULL,
  total DECIMAL(14,2) NOT NULL DEFAULT 0,
  estado ENUM('confirmada','anulada') NOT NULL DEFAULT 'confirmada',
  anulada_em DATETIME NULL,
  anulada_por INT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (utilizador_id) REFERENCES utilizador(id),
  INDEX idx_venda_data (criado_em)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS item_venda (
  id INT AUTO_INCREMENT PRIMARY KEY,
  venda_id INT NOT NULL,
  produto_id INT NOT NULL,
  quantidade INT NOT NULL,
  preco_unitario DECIMAL(12,2) NOT NULL,
  subtotal DECIMAL(14,2) NOT NULL,
  FOREIGN KEY (venda_id) REFERENCES venda(id),
  FOREIGN KEY (produto_id) REFERENCES produto(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS movimento_stock (
  id INT AUTO_INCREMENT PRIMARY KEY,
  produto_id INT NOT NULL,
  tipo ENUM('entrada','saida') NOT NULL,
  motivo ENUM('compra','venda','perda','avaria','devolucao_fornecedor','ajuste','estorno_venda') NOT NULL,
  quantidade INT NOT NULL,
  stock_apos INT NOT NULL,
  referencia_tipo VARCHAR(20) NULL,
  referencia_id INT NULL,
  observacao VARCHAR(255) NULL,
  utilizador_id INT NOT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (produto_id) REFERENCES produto(id),
  FOREIGN KEY (utilizador_id) REFERENCES utilizador(id),
  INDEX idx_mov_produto (produto_id, criado_em)
) ENGINE=InnoDB;
